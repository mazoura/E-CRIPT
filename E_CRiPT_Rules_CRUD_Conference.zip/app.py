from flask import Flask, render_template, request, jsonify
from datetime import datetime, timezone
import json, os, hashlib, uuid

app = Flask(__name__)
DATA_FILE = os.path.join("data", "rules.json")

def load_rules():
    if not os.path.exists(DATA_FILE):
        save_rules([])
    with open(DATA_FILE,"r",encoding="utf-8") as f:
        return json.load(f)

def save_rules(rules):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE,"w",encoding="utf-8") as f:
        json.dump(rules,f,indent=2)

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def rule_matches(rule, prompt):
    t=prompt.lower()
    trigger=(rule.get("trigger") or "").lower()
    if "consent" in trigger:
        return ("record" in t or "patient" in t) and ("without consent" in t or "no consent" in t)
    if "outside" in trigger or "authorizedhours" in trigger:
        return "outside" in t and "hour" in t
    if "disease" in trigger:
        return "disease" in t or "diagnosis" in t
    if "override" in trigger:
        return "override" in t or "bypass" in t
    return False

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/rules")
def get_rules():
    return jsonify(load_rules())

@app.route("/api/rules", methods=["POST"])
def create_rule():
    data=request.get_json() or {}
    rules=load_rules()
    nums=[int(r["id"][1:]) for r in rules if r.get("id","")[1:].isdigit()]
    rid="R"+str(max(nums or [0])+1).zfill(2)
    rule={
        "id":rid,"name":data.get("name","New Ethical Rule").strip(),
        "description":data.get("description","").strip(),
        "level":data.get("level","Logical"),"status":"ACTIVE",
        "priority":int(data.get("priority",5)),
        "trigger":data.get("trigger","").strip(),
        "conditions":data.get("conditions",[]),
        "reactions":data.get("reactions",[]),"version":1,
        "created_at":now(),"updated_at":now()
    }
    rules.append(rule); save_rules(rules)
    return jsonify(rule),201

@app.route("/api/rules/<rid>", methods=["PUT"])
def update_rule(rid):
    rules=load_rules(); data=request.get_json() or {}
    for r in rules:
        if r["id"]==rid:
            for k in ["name","description","level","trigger","conditions","reactions"]:
                if k in data: r[k]=data[k]
            if "priority" in data: r["priority"]=int(data["priority"])
            r["version"]=r.get("version",1)+1; r["updated_at"]=now()
            save_rules(rules); return jsonify(r)
    return jsonify({"error":"Rule not found"}),404

@app.route("/api/rules/<rid>", methods=["DELETE"])
def delete_rule(rid):
    rules=load_rules(); new=[r for r in rules if r["id"]!=rid]
    if len(new)==len(rules): return jsonify({"error":"Rule not found"}),404
    save_rules(new); return jsonify({"deleted":rid})

@app.route("/api/rules/<rid>/toggle", methods=["POST"])
def toggle_rule(rid):
    rules=load_rules()
    for r in rules:
        if r["id"]==rid:
            r["status"]="INACTIVE" if r["status"]=="ACTIVE" else "ACTIVE"
            r["updated_at"]=now(); save_rules(rules); return jsonify(r)
    return jsonify({"error":"Rule not found"}),404

@app.route("/api/inject", methods=["POST"])
def inject():
    ids=(request.get_json() or {}).get("ids",[])
    rules=[r for r in load_rules() if r["id"] in ids and r["status"]=="ACTIVE"]
    digest=hashlib.sha256(json.dumps(rules,sort_keys=True).encode()).hexdigest()
    return jsonify({"count":len(rules),"rules":rules,
        "injection_id":"INJ-"+uuid.uuid4().hex[:10].upper(),
        "hash":digest,"timestamp":now(),"status":"INJECTED"})

@app.route("/api/test", methods=["POST"])
def test_rule():
    data=request.get_json() or {}; prompt=data.get("prompt","").strip()
    ids=data.get("ids",[])
    rules=[r for r in load_rules() if r["id"] in ids and r["status"]=="ACTIVE"]
    triggered=[r for r in rules if rule_matches(r,prompt)]
    if triggered:
        r=sorted(triggered,key=lambda x:x.get("priority",99))[0]
        decision="BLOCKED" if any("block" in x.lower() for x in r["reactions"]) else "REVIEW"
        reason=f"{r['id']} — {r['name']}: {r['description']}"
        response="Request blocked or routed for controlled review under the active ethical policy."
    else:
        decision="ALLOWED"; reason="No selected active rule was triggered."
        response="Request passed the configured policy layer and may proceed to the AI component."
    return jsonify({"decision":decision,"reason":reason,"response":response,
                    "triggered":[r["id"] for r in triggered],"timestamp":now()})

if __name__=="__main__":
    app.run(debug=True,host="127.0.0.1",port=5000)
